var listeJeux;
 var qnt=0;

function Article(id,titre,image,prix,qte){
    this.id=id;
    this.image=image;
    this.titre=titre;
    this.quantite=qte;
    this.prix=prix;
    //this.sousTotal=0;
    
}

function Panier(){
    this.list=[];
    
   this.ajouterArticle=function(id,titre,image,prix,qte){
       var index=this.verifierPanier(id);
    if(index==-1)       
        { 
        this.list.push(new Article(id,titre, image,prix,qte));
   
        }
   else{
       this.list[index].quantite=eval(this.list[index].quantite)+eval(qte);
     
   }
        
      
    }

    this.verifierPanier=function(id){
          for(var i=0;i<this.list.length;i++)
           if(id==this.list[i].id)
             return i;
                     
       return -1;
    }
    
    this.supprimerArticle=function(id){
        var index=this.verifierPanier(id);
        if (index!=-1) this.list.splice(index, 1);
    }
    
}
 var panier=new Panier();

function load(){
    chargerJeux();
    acceuil();
     $('#navTotal').text(0+"$ ("+0+")");
    $('#contact').hide();
}
function listerJeux(){

     $('#tab').detach();
       $('#payer').detach();
    $('#total').detach();
    $('#tableau').detach();
    $('#contact').hide();
    $('#contenu').empty();
  // alert();
	var tabJeux=listeJeux.getElementsByTagName("JEU");
	var taille=tabJeux.length;
  
    for(var i=0;i<taille;i++){
		
        var titre=tabJeux[i].getElementsByTagName("TITRE")[0].firstChild.nodeValue;
		var genre=tabJeux[i].getElementsByTagName("GENRE")[0].firstChild.nodeValue;
		var description=tabJeux[i].getElementsByTagName("DESCRIPTION")[0].firstChild.nodeValue;
        var date=tabJeux[i].getElementsByTagName("DATE")[0].firstChild.nodeValue;
  		var image=tabJeux[i].getElementsByTagName("IMAGE")[0].firstChild.nodeValue;
        var prix=tabJeux[i].getElementsByTagName("PRIX")[0].firstChild.nodeValue;
  
        $('#contenu').append(' <div class="col-md-6 col-xl-3 " style="padding-bottom: 10px"><div class="card"><img  class="card-img-top"  src="'+image+'" alt="'+titre+'"><div class="card-body">    <h5 class="card-title" style="text-align:center;color:red;">'+titre+'</h5><p class="card-text" style="min-height: 240px; text-align:justify">'+description+'</p><input type="text" value="1" id="qnt'+tabJeux[i].getAttribute("id")+'" size="1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:blue;font-size:30px;">'+prix+'$&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><button type="button"  class="btn btn-primary" style="padding-bottom:10px;" onclick="ajouter('+tabJeux[i].getAttribute("id")+');">Ajouter</button></div></div></div>');
    }

    $('#contenu').show();
}



function afficherAction(){

     $('#tab').detach();
    $('#payer').detach();
    $('#total').detach();
    $('#tableau').detach();
    $('#contact').hide();
     $('#contenu').empty();
	var tabJeux=listeJeux.getElementsByTagName("JEU");
	var taille=tabJeux.length;
   
    for(var i=0;i<taille;i++){
		var titre=tabJeux[i].getElementsByTagName("TITRE")[0].firstChild.nodeValue;
		var genre=tabJeux[i].getElementsByTagName("GENRE")[0].firstChild.nodeValue;
		var description=tabJeux[i].getElementsByTagName("DESCRIPTION")[0].firstChild.nodeValue;
        var date=tabJeux[i].getElementsByTagName("DATE")[0].firstChild.nodeValue;
  		var image=tabJeux[i].getElementsByTagName("IMAGE")[0].firstChild.nodeValue;
        var prix=tabJeux[i].getElementsByTagName("PRIX")[0].firstChild.nodeValue;
         if(genre=="Action")
        $('#contenu').append(' <div class="col-md-6 col-xl-3 " style="padding-bottom: 10px;margin:auto;"><div class="card"><img  class="card-img-top"  src="'+image+'" alt="'+titre+'"><div class="card-body">    <h5 class="card-title" style="text-align:center;color:red;">'+titre+'</h5><p class="card-text" style="min-height: 240px; text-align:justify">'+description+'</p><input type="text" value="1" id="qnt'+tabJeux[i].getAttribute("id")+'" size="1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:blue;font-size:30px;">'+prix+'$&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><button type="button"  class="btn btn-primary" style="padding-bottom:10px;" onclick="ajouter('+tabJeux[i].getAttribute("id")+');">Ajouter</button></div></div></div>');
       
    }

    $('#contenu').show();
}

function afficherAventure(){
 
     $('#tab').detach();
    $('#payer').detach();
    $('#total').detach();
    $('#tableau').detach();
    $('#contact').hide();
	var tabJeux=listeJeux.getElementsByTagName("JEU");
	var taille=tabJeux.length;
    $('#contenu').empty();
    
	for(var i=0;i<taille;i++){
		var titre=tabJeux[i].getElementsByTagName("TITRE")[0].firstChild.nodeValue;
		var genre=tabJeux[i].getElementsByTagName("GENRE")[0].firstChild.nodeValue;
		var description=tabJeux[i].getElementsByTagName("DESCRIPTION")[0].firstChild.nodeValue;
        var date=tabJeux[i].getElementsByTagName("DATE")[0].firstChild.nodeValue;
  		var image=tabJeux[i].getElementsByTagName("IMAGE")[0].firstChild.nodeValue;
        var prix=tabJeux[i].getElementsByTagName("PRIX")[0].firstChild.nodeValue;
         if(genre=="Aventure")
       $('#contenu').append(' <div class="col-md-6 col-xl-3 " style="padding-bottom: 10px; margin:auto;"><div class="card"><img  class="card-img-top"  src="'+image+'" alt="'+titre+'"><div class="card-body">    <h5 class="card-title" style="text-align:center;color:red;">'+titre+'</h5><p class="card-text" style="min-height: 240px; text-align:justify">'+description+'</p><input type="text" value="1" id="qnt'+tabJeux[i].getAttribute("id")+'" size="1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:blue;font-size:30px;">'+prix+'$&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><button type="button"  class="btn btn-primary" style="padding-bottom:10px;" onclick="ajouter('+tabJeux[i].getAttribute("id")+');">Ajouter</button></div></div></div>');
    }

    $('#contenu').show();
}
function afficherStrategie(){
    $('#tab').detach();
    $('#payer').detach();
    $('#total').detach();
    $('#tableau').detach();
    $('#contact').hide();
	var tabJeux=listeJeux.getElementsByTagName("JEU");
	var taille=tabJeux.length;
    $('#contenu').empty();
    
	for(var i=0;i<taille;i++){
		var titre=tabJeux[i].getElementsByTagName("TITRE")[0].firstChild.nodeValue;
		var genre=tabJeux[i].getElementsByTagName("GENRE")[0].firstChild.nodeValue;
		var description=tabJeux[i].getElementsByTagName("DESCRIPTION")[0].firstChild.nodeValue;
        var date=tabJeux[i].getElementsByTagName("DATE")[0].firstChild.nodeValue;
  		var image=tabJeux[i].getElementsByTagName("IMAGE")[0].firstChild.nodeValue;
        
         var prix=tabJeux[i].getElementsByTagName("PRIX")[0].firstChild.nodeValue;
         if(genre=="Stratégie")
       $('#contenu').append(' <div class="col-md-6 col-xl-3 " style="padding-bottom: 10px;margin:auto;"><div class="card"><img  class="card-img-top"  src="'+image+'" alt="'+titre+'"><div class="card-body">    <h5 class="card-title" style="text-align:center;color:red;">'+titre+'</h5><p class="card-text" style="min-height: 240px; text-align:justify">'+description+'</p><input type="text" value="1" id="qnt'+tabJeux[i].getAttribute("id")+'" size="1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:blue;font-size:30px;">'+prix+'$&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><button type="button"  class="btn btn-primary" style="padding-bottom:10px;" onclick="ajouter('+tabJeux[i].getAttribute("id")+');">Ajouter</button></div></div></div>');
        
    }
  
    $('#contenu').show();
}

function afficherSport(){
 
     $('#tab').detach();
       $('#payer').detach();
    $('#total').detach();
    $('#tableau').detach();
    $('#contact').hide();
	var tabJeux=listeJeux.getElementsByTagName("JEU");
	var taille=tabJeux.length;
    $('#contenu').empty();
    
	for(var i=0;i<taille;i++){
		var titre=tabJeux[i].getElementsByTagName("TITRE")[0].firstChild.nodeValue;
		var genre=tabJeux[i].getElementsByTagName("GENRE")[0].firstChild.nodeValue;
		var description=tabJeux[i].getElementsByTagName("DESCRIPTION")[0].firstChild.nodeValue;
        var date=tabJeux[i].getElementsByTagName("DATE")[0].firstChild.nodeValue;
  		var image=tabJeux[i].getElementsByTagName("IMAGE")[0].firstChild.nodeValue;
         var prix=tabJeux[i].getElementsByTagName("PRIX")[0].firstChild.nodeValue;
         if(genre=="Sport")
       $('#contenu').append(' <div class="col-md-6 col-xl-3 " style="padding-bottom: 10px;margin:auto;"><div class="card"><img  class="card-img-top"  src="'+image+'" alt="'+titre+'"><div class="card-body">    <h5 class="card-title" style="text-align:center;color:red;">'+titre+'</h5><p class="card-text" style="min-height: 240px; text-align:justify">'+description+'</p><input type="text" value="1" id="qnt'+tabJeux[i].getAttribute("id")+'" size="1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span style="color:blue;font-size:30px;">'+prix+'$&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span><button type="button"  class="btn btn-primary" style="padding-bottom:10px;" onclick="ajouter('+tabJeux[i].getAttribute("id")+');">Ajouter</button></div></div></div>');
    }
 
    $('#contenu').show();
}

function ajouter(id){

    var tabJeux=listeJeux.getElementsByTagName("JEU");
	var taille=tabJeux.length;
    for(var i=0;i<taille;i++){
        var idArticle=tabJeux[i].getAttribute("id");
 
        if(idArticle==id){

            var qte=document.getElementById("qnt"+tabJeux[i].getAttribute("id")).value;
            panier.ajouterArticle(id,tabJeux[i].getElementsByTagName("TITRE")[0].firstChild.nodeValue,tabJeux[i].getElementsByTagName("IMAGE")[0].firstChild.nodeValue, tabJeux[i].getElementsByTagName("PRIX")[0].firstChild.nodeValue, qte);
            qnt=eval(qnt)+eval(qte);
        }
          
    } 

 $('#navTotal').text(calculerTotal()+"$ ("+qnt+")");
}
function calculerTotal(){
     var total=0;
    for(var i=0;i<panier.list.length;i++){
        var sousTotal=eval(panier.list[i].prix*panier.list[i].quantite);
        total+=sousTotal;
     //   qnt=eval(qnt+prix*panier.list[i].quantite);
    }
    
    return total;
}
function afficherPanier(){
  //  $('#contenuLeft').hide();
  //   $('#contenuRight').hide();
    $('#contenu').hide()
    $('#contact').hide();
   $('#tab').detach();
    $('#payer').detach();
    $('#total').detach();

    $('#panier').append('<table id ="tab" class="table">');
    $('#tab').append('<tr><th></th><th>Produit</th><th>Quantité</th><th>Prix</th><th>Sous total</th><th></th></tr>');
    var total=0;
   
    for(var i=0;i<panier.list.length;i++){
        var sousTotal=eval(panier.list[i].prix*panier.list[i].quantite);

        $('table').append('<tr><td><img width=\"100\" src="'+panier.list[i].image+'"/></td><td>'+panier.list[i].titre+'</td><td id="qnt'+panier.list[i].id+'">'+panier.list[i].quantite+'</td><td>'+panier.list[i].prix+'</td><td>'+sousTotal+'</td><td><button type="button" class="btn btn-primary" style="width: 120px" onclick="supprimer('+panier.list[i].id+');">Supprimer</button></td></tr>');
  
    }
    total=calculerTotal();
    $('table').append('<tr><td></td><td></td><td></td><td></td><td><span id="total" style="font-style: oblique; font-weight: bold; font-size: large;"></td><td><button type="button" id=\"payer\" style="width: 120px" class="btn btn-danger " onclick="afficherFacture('+total+');">Payer</button> </td></tr>');
       $('#total').text("Total: "+total+"$");
}

function afficherFacture(somme){
    confirm("\n\nVous avez acheté "+qnt+" jeux\nTotal: "+somme);
}
function supprimer(id){
    for(var i=0;i<panier.list.length;i++)
        if(panier.list[i].id==id)
               {  
                   var qte=panier.list[i].quantite;
                    panier.supprimerArticle(id);
               
                    qnt=eval(qnt)-eval(qte);
                     $('#navTotal').text(calculerTotal()+"$ ("+qnt+")");
                    afficherPanier();
               }
}
function contact(){
   $('#contenu').hide()
    $('#contact').hide();
   $('#tab').detach();
    $('#payer').detach();
    $('#total').detach();
    $('#contact').show();
}

function acceuil()
{

     $('#tab').detach();
       $('#payer').detach();
    $('#total').detach();
    $('#tableau').detach();
    $('#contact').hide();
    $('#contenu').empty();
 
 
        $('#contenu').append('<a style="cursor:pointer;" onclick="afficherAction();" <div class="col-md-6 col-xl-3 " style="padding-bottom: 10px"><div class="card"><img  class="card-img-top"  src="images/catAction.jpg" ><div class="card-body"> <h5 class="card-title" style="text-align:center;color:red;">Action</h5></div></div></div></a>');
    
       $('#contenu').append('<a style="cursor:pointer;" onclick="afficherAventure();" <div class="col-md-6 col-xl-3 " style="padding-bottom: 10px"><div class="card"><img  class="card-img-top"  src="images/catAventure.jpg" ><div class="card-body">    <h5 class="card-title" style="text-align:center;color:red;">Aventure</h5></div></div></div></a>');
    
       $('#contenu').append('<a style="cursor:pointer;" onclick="afficherStrategie();" <div class="col-md-6 col-xl-3 " style="padding-bottom: 10px"><div class="card"><img  class="card-img-top"  src="images/catStrategie.jpg" ><div class="card-body">    <h5 class="card-title" style="text-align:center;color:red;">Stratégie</h5></div></div></div></a>');
    
       $('#contenu').append('<a style="cursor:pointer;" onclick="afficherSport();" <div class="col-md-6 col-xl-3 " style="padding-bottom: 10px"><div class="card"><img  class="card-img-top"  src="images/catSport.jpg" ><div class="card-body">    <h5 class="card-title" style="text-align:center;color:red;">Sport</h5></div></div></div></a>');
 
   
    $('#contenu').show();
}


function chargerJeux(){
	$.ajax({
		type:"GET",
		url:"donnees/jeux.xml",
		dataType:"xml",
		success : function(liste){
			listeJeux=liste;
		},
		fail : function(){
			alert("GROS PROBLEME");
		}
	});
}