A Pen created at CodePen.io. You can find this one at https://codepen.io/ivillamil/pen/jWjgzE.

 This demo shows how to change the style and layout of a table according to the available space.