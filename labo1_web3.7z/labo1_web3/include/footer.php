
<div class="marge-haut pied"><p>&nbsp;&nbsp;Collège Maisonneuve, groupe 16701 / Benjamin Fian, Elena Maslakova, Octavian Catanoi, Yassine Semmar</p></div>

<form id="form_sauver" action="viewsfilms/logout.php" method="POST">
    <input id="sauverPanier" name="sauverPanier" type="hidden">
</form>

</body>

</html>

<?php
unset($connexion);
unset($stmt);
?>