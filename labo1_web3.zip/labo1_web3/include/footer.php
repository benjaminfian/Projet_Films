
<div class="marge-haut pied"><p>&nbsp;&nbsp;Collège Maisonneuve, groupe 16701 / Benjamin Fian, Elena Maslakova, Octavian Catanoi, Yassine Semmar</p></div>
    
</body>
<!--<script>$(document).ready(affichPanier());</script>-->
</html>

<?php
unset($connexion);
unset($stmt);
?>