<?php
?>

<div><p>&nbsp;&nbsp;Collège Maisonneuve, groupe 16701 / Benjamin Fian</p></div>
    
</body>
</html>

<?php
unset($connexion);
unset($stmt);
?>