<?php
include 'include/header.php';
?>      
        <div class="row mt-5 justify-content-center">
            
            <div class="card img_accueil mx-2 mb-3 text-center">
                <a onclick="lister(1)" href="#">
                    <img src="images/logo.png" alt="" class="card-img-top">
                </a>
                <div class="card-body">
                    <h5 class="card-title text-titre" >Action</h5>
                </div>
            </div>
            
            <div class="card img_accueil mx-2 mb-3 text-center">
                <a onclick="lister(2)" href="#">
                    <img src="images/logo.png" alt="" class="card-img-top">
                </a>
                <div class="card-body">
                    <h5 class="card-title text-titre">Drame</h5>
                </div>
            </div>
            
            <div class="card img_accueil mx-2 mb-3 text-center">
                <a onclick="lister(3)" href="#">
                    <img src="images/logo.png" alt="" class="card-img-top">
                </a>
                <div class="card-body">
                    <h5 class="card-title text-titre">Horreur</h5>
                </div>
            </div>
            
            <div class="card img_accueil mx-2 mb-3 text-center">
                <a onclick="lister(4)" href="#">
                    <img src="images/logo.png" alt="" class="card-img-top">
                </a>
                <div class="card-body">
                    <h5 class="card-title text-titre">Science-fiction</h5>
                </div>
            </div>
            
<?php
include 'include/footer.php';
?>
    


    
    
