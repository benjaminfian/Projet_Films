function deconnexion()
{    
    document.getElementById('form_logout').submit();    
}

function lister(id)
{
    if(id == null)
    {
        document.getElementById('form_listeFilm').submit();
    }
    else if (id == 1)
    {        
        document.getElementById('form_listeFilmAction').submit();
    }
    else if (id == 2)
    {        
        document.getElementById('form_listeFilmDrame').submit();
    }
    else if (id == 3)
    {        
        document.getElementById('form_listeFilmHorreur').submit();
    }
    else if (id == 4)
    {        
        document.getElementById('form_listeFilmSF').submit();
    }
}

function getQuantite()
{
    return document.getElementById("quantite").value;
}

function commander()
{
    var panier = JSON.parse(localStorage.getItem('panier'));    
    for (var i=0;i<panier.length;i++)
    {
        var idFilm = document.getElementById('idFilm')
        idFilm.value = panier[i].id;        
        
        var idFilm = document.getElementById('quantite')
        quantite.value = panier[i].quantite;
        
        document.getElementById('form_commande').submit();
    }    
    vider();
}