function deconnexion()
{    
    document.getElementById('form_logout').submit();    
}

function lister(id)
{
    if(id == null)
    {
        document.getElementById('form_listeFilm').submit();
    }
    else if (id == 1)
    {        
        document.getElementById('form_listeFilmAction').submit();
    }
    else if (id == 2)
    {        
        document.getElementById('form_listeFilmDrame').submit();
    }
    else if (id == 3)
    {        
        document.getElementById('form_listeFilmHorreur').submit();
    }
    else if (id == 4)
    {        
        document.getElementById('form_listeFilmSF').submit();
    }
}