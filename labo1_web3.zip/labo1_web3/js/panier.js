var listePanier = [],nbrItemPanier = 0,prixPanierTotal = 0;

/*function chargerJeux(){
	$.ajax({
		type:"GET",
		url:"donnees/jeux.xml",
		dataType:"xml",
		success : function(liste){
			listeJeux=liste;			
		},
		fail : function(){
			alert("Le fichier de données xml n'a pas pu être chargé");
		}
	});
    var d = new Date();    
    $('#date').html(d);
    accueil();    
}

function accueil()
{    
    var rep="<h2>Catégorie de jeux</h2><div class=\"card-deck\"><div class=\"card\"><img src=\"images/pc.jpg\" class=\"card-img-top\" alt=\"PC\" title=\"cliquez pour avoir la liste des jeux sur PC\"onclick=\"listerJeux(\'PC\')\"><div class=\"card-body\"><h5 class=\"card-title\">PC</h5></div></div><div class=\"card\"><img src=\"images/switch.jpg\" class=\"card-img-top\" alt=\"Nintendo Switch\" title=\"cliquez pour avoir la liste des jeux sur Nintendo Switch\" onclick=\"listerJeux(\'SWITCH\')\"><div class=\"card-body\"><h5 class=\"card-title\">Nintendo Switch</h5></div></div><div class=\"card\"><img src=\"images/ps4.jpg\" class=\"card-img-top\" alt=\"Playstation 4\" title=\"cliquez pour avoir la liste des jeux sur Playstation 4\" onclick=\"listerJeux(\'PS4\')\"><div class=\"card-body\"><h5 class=\"card-title\">Playstation 4</h5>     </div></div><div class=\"card\"><img src=\"images/xboxone.jpg\" class=\"card-img-top\" alt=\"Xbox One\" title=\"cliquez pour avoir la liste des jeux sur Xbox One\" onclick=\"listerJeux(\'XBOX ONE\')\">                <div class=\"card-body\"> <h5 class=\"card-title\">Xbox One</h5></div></div></div>";
    $('#contenu').html(rep);
    totalPanier();
}

function contact()
{
    
    var rep="<div class=\"container\"><form><div class=\"row\"><div><h2>Formulaire de contact</h2><br/><p>Les champs obligatoires sont suivis par *.</p></div></div><br /><div class=\"row\"><div class=\"offset-2 col-md-4\">  <fieldset><legend>Titre</legend><input type=\"radio\" name=\"sexe\" value=\"homme\"> Monsieur<br><input type=\"radio\" name=\"sexe\" value=\"femme\"> Madame<br></fieldset></div></div><br/><div class=\"row\">             <div class=\"col-md-2 text-right\">Nom :</div><div class=\"col-md-4\"><input class=\"form-control\" type=\"text\" name=\"nom\" required></div>*</div><br/><div class=\"row\"><div class=\"col-md-2 text-right\">Prénom :</div><div class=\"col-md-4\"><input class=\"form-control\" type=\"text\" name=\"nom\" required></div>*</div><br/><div class=\"row\"><div class=\"col-md-2 text-right\">Courriel :</div><div class=\"col-md-4\"><input class=\"form-control\" type=\"email\" name=\"mail\" required></div>*</div><br/><div class=\"row\"><div class=\"col-md-2 text-right\">Téléphone :</div><div class=\"col-md-4\"><input class=\"form-control\" type=\"email\" name=\"mail\" required></div>*</div><br/><div class=\"row\"><div class=\"col-md-2\"></div><input class=\"col-md-2  btn btn-success\" type=\"submit\"onclick=\"envoie()\"></div></form></div>";
    $('#contenu').html(rep);
}

function listerJeux(support)
{        
	var categorie, nom, prix,image;
	var tabJeux=listeJeux.getElementsByTagName("JEU");
	var taille=tabJeux.length;
	var rep="";
    if (support != null)
        {
            if (support === "PC")
            {
                rep+="<h2>Liste des jeux PC</h2>";
            }
            else if (support === "SWITCH")
            {
                rep+="<h2>Liste des jeux Nintendo Switch</h2>";
            }
            else if (support === "PS4")
            {
                rep+="<h2>Liste des jeux PS4</h2>";
            }
            else if (support === "XBOX ONE")
            {
                rep+="<h2>Liste des jeux Xbox One</h2>";
            }
            rep+="<div class=\"container\"><div class=\"row\"><div class=\"col-sm-12 col-md-10 col-md-offset-1\"><table class=\"table table-hover\"><thead><tr><th>Produit</th><th class=\"text-center\">Prix</th><th> </th>    </tr></thead><tbody>";
        }
    
    else
        {
            rep+="<h2>Liste des jeux toutes catégories</h2>";
            rep+="<div class=\"container\"><div class=\"row\"><div class=\"col-sm-12 col-md-10 col-md-offset-1\"><table class=\"table table-hover\"><thead><tr><th>Produit</th><th class=\"text-center\">Catégorie</th>         <th class=\"text-center\">Prix</th><th> </th></tr></thead><tbody>";
        }
    
	for (var i=0;i<taille;i++)
    {           
		categorie=tabJeux[i].getElementsByTagName("CATEGORIE")[0].firstChild.nodeValue;
		nom=tabJeux[i].getElementsByTagName("NOM")[0].firstChild.nodeValue;
        prix=tabJeux[i].getElementsByTagName("PRIX")[0].firstChild.nodeValue;
        image=tabJeux[i].getElementsByTagName("IMGSRC")[0].firstChild.nodeValue;
        if (support == null)
            {           
              rep+="<tr><td class=\"col-sm-8 col-md-10\"><div class=\"media\"><a class=\"thumbnail pull-left\" href=\"#\"> <img class=\"boite\" src=\'"+image+"\' alt=\"Jeu "+categorie+"\" title=\"image de la boite du jeu"+nom+"\"></a><div class=\"media-body\"><h4 class=\"media-heading\"><a href=\"#\">"+nom+"</a></h4></div></div></td><td class=\"col-sm-1 col-md-1 text-center\"><strong>"+categorie+"</strong></td>              <td class=\"col-sm-1 col-md-1 text-center\"><strong>"+prix+"&nbsp;$</strong></td><td class=\"col-sm-1 col-md-1\"><button type=\"button\" class=\"btn btn-success\" onclick=\"ajouter(\'"+nom+"\')\">Ajouter</button></td></tr>";
            }
        else if (categorie === support)
            {
              rep+="<tr><td class=\"col-sm-8 col-md-10\"><div class=\"media\"><a class=\"thumbnail pull-left\" href=\"#\"> <img class=\"boite\" src=\'"+image+"\' alt=\"Jeu "+categorie+"\" title=\"image de la boite du jeu"+nom+"\"></a><div class=\"media-body\"><h4 class=\"media-heading\"><a href=\"#\">"+nom+"</a></h4></div></div></td><td class=\"col-sm-1 col-md-1 text-center\"><strong>"+prix+"&nbsp;$</strong></td>                <td class=\"col-sm-1 col-md-1\"><button type=\"button\" class=\"btn btn-success\" onclick=\"ajouter(\'"+nom+"\')\">Ajouter</button></td></tr>";
            }        
	}
    rep+="</tbody></table></div></div></div>";
	$('#contenu').html(rep);	
}*/

function ajouter(image, titre, prix, id)
{    
    /*var sel = document.getElementById("quantite"+id+"");
    var value = sel.options[sel.selectedIndex].value;
    alert(image+" "+titre+" "+value+" "+prix);*/
    var sel = document.getElementById("quantite"+id+"");
    var quantite = parseInt(sel.options[sel.selectedIndex].value);
    var film={"image":image,"titre":titre,"quantite":quantite,"prix":prix,"id":id};
      
    var taille=listePanier.length;
    if (taille === 0)
        {            
            listePanier.push(film);            
        }
    else 
    {
        var j = 0;
        for (j=0;j<taille;j++)
        {
            var unFilm=listePanier[j];
            if(unFilm.id == id)
            {                
                 unFilm.quantite+=quantite;                
                 break;
            }            
        }
        if (j == taille)
            {                
                listePanier.push(film);                
            }
    }
    totalPanier();    
    localStorage.setItem('panier', JSON.stringify(listePanier));
    localStorage.setItem('nombre', JSON.stringify(nbrItemPanier));
    localStorage.setItem('prix', JSON.stringify(prixPanierTotal));
}

function supprimer(id)
{
    var taille=listePanier.length;
    for (var i=0;i<taille;i++)
    {
        var unFilm=listePanier[i];
        if(unFilm.id == id)
            {                
                listePanier.splice(i, 1);
                break;
            }        
    }
    totalPanier();
    localStorage.setItem('panier', JSON.stringify(listePanier));
    localStorage.setItem('nombre', JSON.stringify(nbrItemPanier));
    localStorage.setItem('prix', JSON.stringify(prixPanierTotal));
    affichPanier();    
}

function retirer(id)
{
    var taille=listePanier.length;
    for (var i=0;i<taille;i++)
    {
        var unFilm=listePanier[i];
        if(unFilm.id == id)
            {                
                listePanier[i].quantite--;
                break;
            }        
    }
    totalPanier();
    localStorage.setItem('panier', JSON.stringify(listePanier));
    localStorage.setItem('nombre', JSON.stringify(nbrItemPanier));
    localStorage.setItem('prix', JSON.stringify(prixPanierTotal));
    affichPanier();
}

function load()
{
    if (localStorage.getItem('panier') !== null) 
    {        
        listePanier = JSON.parse(localStorage.getItem('panier'));
        nbrItemPanier = JSON.parse(localStorage.getItem('nombre'));
        prixPanierTotal = JSON.parse(localStorage.getItem('prix'));
    }
    totalPanier();
    affichPanier();
}

function affichPanier()
{    
    var image, titre, quantite = 0,prix = 0;
    $('#contenu').html("");
    var rep = "";	
	var taille=listePanier.length;
    var totalHT = 0;
	rep+="<h2>Liste des films dans votre panier</h2><br><br><div class=\"row custom-center\"><div class=\"col-sm-12 col-md-10 col-md-offset-1 custom-center\"><button type=\"button\" class=\"btn btn-danger marge-bas float-right\" onclick=\"vider()\">Vider le panier</button><table class=\"table table-hover table-striped\"><thead><tr><th>Pochette</th><th class=\"text-center\">Titre</th><th class=\"text-center\">Quantité</th><th class=\"text-center\">Prix</th><th> </th><th> </th><th> </th></tr></thead><tbody>";
	for (var i=0;i<taille;i++){
		var unFilm=listePanier[i];
		image=unFilm.image;
		titre=unFilm.titre;
        quantite=unFilm.quantite;
        prix=unFilm.prix;
        id=unFilm.id;
        		
        rep+="<tr><td class=\"col-sm-1 col-md-1\"><div class=\"media\"><img class=\"img_crud\" src=\'../pochettes/"+image+"\' alt=\"Film numéro "+id+"\" title=\"image de la boite du film "+titre+"\"></a></div></td><td class=\"col-sm-1 col-md-1 text-center\">"+titre+"</td><td class=\"col-sm-1 col-md-1 text-center\">"+quantite+"</td><td class=\"col-sm-1 col-md-1 text-center\">"+prix.toFixed(2)+"$</td>";
        if (unFilm.quantite == 1)
            {
                rep+="<td class=\"col-sm-1 col-md-1\"></td><td class=\"col-sm-1 col-md-1 text-center\"><button type=\"button\" class=\"btn btn-danger\" onclick=\"supprimer(\'"+id+"\')\">Supprimer</button></td>";                
            }
        else
            {
                rep+="<td class=\"col-sm-1 col-md-1 text-center\"><button type=\"button\" class=\"btn btn-warning\" onclick=\"retirer(\'"+id+"\')\">Enlever 1 film</button></td><td class=\"col-sm-1 col-md-1 text-center\"><button type=\"button\" class=\"btn btn-danger\" onclick=\"supprimer(\'"+id+"\')\">Supprimer</button></td>";                
            }
        rep+="<td class=\"col-sm-1 col-md-1\"></td></tr>";
        totalHT += (prix * quantite);
	}
    rep+="</tbody><tfoot><tr><td>   </td><td>   </td><td>   </td><td>   </td><td>   </td><td></td><td class=\"text-right\"><h3><strong>Sous-total:&nbsp;</strong>"+totalHT.toFixed(2)+"&nbsp;$</h3></td></tr>     <tr><td>   </td><td>   </td><td>   </td><td>   </td><td>   </td><td></td><td class=\"text-right\"><h3><strong>TVQ:&nbsp;</strong>"+(totalHT * 0.09975).toFixed(2)+"&nbsp;$</h3></td></tr>     <tr><td>   </td><td>   </td><td>   </td><td>   </td><td>   </td><td></td><td class=\"text-right\"><h3><strong>TPS:&nbsp;</strong>"+(totalHT * 0.05).toFixed(2)+"&nbsp;$</h3></td></tr>     <tr><td>   </td><td>   </td><td>   </td><td>   </td><td>   </td><td></td><td class=\"text-right\"><h3><strong>Total:&nbsp;</strong>"+(totalHT * 1.14975).toFixed(2)+"&nbsp;$</h3></td></tr></tfoot></table><button type=\"button\" class=\"btn btn-primary marge-bas float-right\" onclick=\"commander()\">Commander</button></div></div>";    
	$('#contenu').html(rep);	
}

function totalPanier()
{
    nbrItemPanier = 0;
    prixPanierTotal = 0;
    var taille=listePanier.length;    
    for (var i=0;i<taille;i++)
    {
        nbrItemPanier+= listePanier[i].quantite;
        prixPanierTotal += listePanier[i].quantite * listePanier[i].prix;
    }
    var rep = "("+nbrItemPanier+") "+prixPanierTotal.toFixed(2)+" $"
    $('#totalPanier').html(rep);
}

function vider()
{
    listePanier = [];
    nbrItemPanier = 0;
    prixPanierTotal = 0;
    localStorage.removeItem('panier');
    localStorage.removeItem('nombre');
    localStorage.removeItem('prix');
    totalPanier();
    affichPanier();
}

/*function chercher()
{    
    var categorie, nom, prix,image;
    var titre = $('#recherche').val();    
	var tabJeux=listeJeux.getElementsByTagName("JEU");
	var taille=tabJeux.length;
	var rep="";    
	for (var i=0;i<taille;i++)
    {           
		categorie=tabJeux[i].getElementsByTagName("CATEGORIE")[0].firstChild.nodeValue;
		nom=tabJeux[i].getElementsByTagName("NOM")[0].firstChild.nodeValue;
        prix=tabJeux[i].getElementsByTagName("PRIX")[0].firstChild.nodeValue;
        image=tabJeux[i].getElementsByTagName("IMGSRC")[0].firstChild.nodeValue;
        if (nom == titre)
            {                
                rep+="<h2>Résultat de votre recherche</h2>";
                rep+="<tr><div class=\"container\"><div class=\"row\"><div class=\"col-sm-12 col-md-10 col-md-offset-1\"><table class=\"table table-hover\"><thead><tr><th>Produit</th><th class=\"text-center\">Catégorie</th> <th class=\"text-center\">Prix</th><th> </th></tr></thead><tbody><td class=\"col-sm-8 col-md-10\"><div class=\"media\"><a class=\"thumbnail pull-left\" href=\"#\"> <img class=\"boite\" src=\'"+image+"\' alt=\"Jeu "+categorie+"\" title=\"image de la boite du jeu"+nom+"\"></a><div class=\"media-body\"><h4 class=\"media-heading\"><a href=\"#\">"+nom+"</a></h4></div></div></td><td class=\"col-sm-1 col-md-1 text-center\"><strong>"+categorie+"</strong></td><td class=\"col-sm-1 col-md-1 text-center\"><strong>"+prix+"&nbsp;$</strong></td><td class=\"col-sm-1 col-md-1\"><button type=\"button\" class=\"btn btn-success\" onclick=\"ajouter(\'"+nom+"\')\">Ajouter</button></td></tr></tbody></table></div></div></div>";
                break;
            }        
	}
    if (i == taille)
        {
            rep+="<h2>Aucun jeu du nom de "+titre+" n'a été trouvé dans notre boutique</h2>"
        }
	$('#contenu').html(rep);
}

function envoie()
{
    alert("Message envoyé");
}

function test()
{
    var rep ="<div>test</div>";
    $('#contenu').html(rep);
}*/





