var listeJeux = null, listePanier = [],nbrItemPanier ,prixPanierTotal = 0;

/*function chargerJeux(){
	$.ajax({
		type:"GET",
		url:"donnees/jeux.xml",
		dataType:"xml",
		success : function(liste){
			listeJeux=liste;			
		},
		fail : function(){
			alert("Le fichier de données xml n'a pas pu être chargé");
		}
	});
    var d = new Date();    
    $('#date').html(d);
    accueil();    
}

function accueil()
{    
    var rep="<h2>Catégorie de jeux</h2><div class=\"card-deck\"><div class=\"card\"><img src=\"images/pc.jpg\" class=\"card-img-top\" alt=\"PC\" title=\"cliquez pour avoir la liste des jeux sur PC\"onclick=\"listerJeux(\'PC\')\"><div class=\"card-body\"><h5 class=\"card-title\">PC</h5></div></div><div class=\"card\"><img src=\"images/switch.jpg\" class=\"card-img-top\" alt=\"Nintendo Switch\" title=\"cliquez pour avoir la liste des jeux sur Nintendo Switch\" onclick=\"listerJeux(\'SWITCH\')\"><div class=\"card-body\"><h5 class=\"card-title\">Nintendo Switch</h5></div></div><div class=\"card\"><img src=\"images/ps4.jpg\" class=\"card-img-top\" alt=\"Playstation 4\" title=\"cliquez pour avoir la liste des jeux sur Playstation 4\" onclick=\"listerJeux(\'PS4\')\"><div class=\"card-body\"><h5 class=\"card-title\">Playstation 4</h5>     </div></div><div class=\"card\"><img src=\"images/xboxone.jpg\" class=\"card-img-top\" alt=\"Xbox One\" title=\"cliquez pour avoir la liste des jeux sur Xbox One\" onclick=\"listerJeux(\'XBOX ONE\')\">                <div class=\"card-body\"> <h5 class=\"card-title\">Xbox One</h5></div></div></div>";
    $('#contenu').html(rep);
    totalPanier();
}

function contact()
{
    
    var rep="<div class=\"container\"><form><div class=\"row\"><div><h2>Formulaire de contact</h2><br/><p>Les champs obligatoires sont suivis par *.</p></div></div><br /><div class=\"row\"><div class=\"offset-2 col-md-4\">  <fieldset><legend>Titre</legend><input type=\"radio\" name=\"sexe\" value=\"homme\"> Monsieur<br><input type=\"radio\" name=\"sexe\" value=\"femme\"> Madame<br></fieldset></div></div><br/><div class=\"row\">             <div class=\"col-md-2 text-right\">Nom :</div><div class=\"col-md-4\"><input class=\"form-control\" type=\"text\" name=\"nom\" required></div>*</div><br/><div class=\"row\"><div class=\"col-md-2 text-right\">Prénom :</div><div class=\"col-md-4\"><input class=\"form-control\" type=\"text\" name=\"nom\" required></div>*</div><br/><div class=\"row\"><div class=\"col-md-2 text-right\">Courriel :</div><div class=\"col-md-4\"><input class=\"form-control\" type=\"email\" name=\"mail\" required></div>*</div><br/><div class=\"row\"><div class=\"col-md-2 text-right\">Téléphone :</div><div class=\"col-md-4\"><input class=\"form-control\" type=\"email\" name=\"mail\" required></div>*</div><br/><div class=\"row\"><div class=\"col-md-2\"></div><input class=\"col-md-2  btn btn-success\" type=\"submit\"onclick=\"envoie()\"></div></form></div>";
    $('#contenu').html(rep);
}

function listerJeux(support)
{        
	var categorie, nom, prix,image;
	var tabJeux=listeJeux.getElementsByTagName("JEU");
	var taille=tabJeux.length;
	var rep="";
    if (support != null)
        {
            if (support === "PC")
            {
                rep+="<h2>Liste des jeux PC</h2>";
            }
            else if (support === "SWITCH")
            {
                rep+="<h2>Liste des jeux Nintendo Switch</h2>";
            }
            else if (support === "PS4")
            {
                rep+="<h2>Liste des jeux PS4</h2>";
            }
            else if (support === "XBOX ONE")
            {
                rep+="<h2>Liste des jeux Xbox One</h2>";
            }
            rep+="<div class=\"container\"><div class=\"row\"><div class=\"col-sm-12 col-md-10 col-md-offset-1\"><table class=\"table table-hover\"><thead><tr><th>Produit</th><th class=\"text-center\">Prix</th><th> </th>    </tr></thead><tbody>";
        }
    
    else
        {
            rep+="<h2>Liste des jeux toutes catégories</h2>";
            rep+="<div class=\"container\"><div class=\"row\"><div class=\"col-sm-12 col-md-10 col-md-offset-1\"><table class=\"table table-hover\"><thead><tr><th>Produit</th><th class=\"text-center\">Catégorie</th>         <th class=\"text-center\">Prix</th><th> </th></tr></thead><tbody>";
        }
    
	for (var i=0;i<taille;i++)
    {           
		categorie=tabJeux[i].getElementsByTagName("CATEGORIE")[0].firstChild.nodeValue;
		nom=tabJeux[i].getElementsByTagName("NOM")[0].firstChild.nodeValue;
        prix=tabJeux[i].getElementsByTagName("PRIX")[0].firstChild.nodeValue;
        image=tabJeux[i].getElementsByTagName("IMGSRC")[0].firstChild.nodeValue;
        if (support == null)
            {           
              rep+="<tr><td class=\"col-sm-8 col-md-10\"><div class=\"media\"><a class=\"thumbnail pull-left\" href=\"#\"> <img class=\"boite\" src=\'"+image+"\' alt=\"Jeu "+categorie+"\" title=\"image de la boite du jeu"+nom+"\"></a><div class=\"media-body\"><h4 class=\"media-heading\"><a href=\"#\">"+nom+"</a></h4></div></div></td><td class=\"col-sm-1 col-md-1 text-center\"><strong>"+categorie+"</strong></td>              <td class=\"col-sm-1 col-md-1 text-center\"><strong>"+prix+"&nbsp;$</strong></td><td class=\"col-sm-1 col-md-1\"><button type=\"button\" class=\"btn btn-success\" onclick=\"ajouter(\'"+nom+"\')\">Ajouter</button></td></tr>";
            }
        else if (categorie === support)
            {
              rep+="<tr><td class=\"col-sm-8 col-md-10\"><div class=\"media\"><a class=\"thumbnail pull-left\" href=\"#\"> <img class=\"boite\" src=\'"+image+"\' alt=\"Jeu "+categorie+"\" title=\"image de la boite du jeu"+nom+"\"></a><div class=\"media-body\"><h4 class=\"media-heading\"><a href=\"#\">"+nom+"</a></h4></div></div></td><td class=\"col-sm-1 col-md-1 text-center\"><strong>"+prix+"&nbsp;$</strong></td>                <td class=\"col-sm-1 col-md-1\"><button type=\"button\" class=\"btn btn-success\" onclick=\"ajouter(\'"+nom+"\')\">Ajouter</button></td></tr>";
            }        
	}
    rep+="</tbody></table></div></div></div>";
	$('#contenu').html(rep);	
}*/

function ajouter(titre)
{    
    var jeu={"image":null,"nom":null,"prix":null,"categorie":null,"quantite":0};
    var tabJeux=listeJeux.getElementsByTagName("JEU");
    var taille=tabJeux.length;    
    for (var i=0;i<taille;i++)
        {
            image=tabJeux[i].getElementsByTagName("IMGSRC")[0].firstChild.nodeValue;
		    nom=tabJeux[i].getElementsByTagName("NOM")[0].firstChild.nodeValue;
            prix=tabJeux[i].getElementsByTagName("PRIX")[0].firstChild.nodeValue;
            categorie=tabJeux[i].getElementsByTagName("CATEGORIE")[0].firstChild.nodeValue;
            if (nom == titre)
                {
                    jeu.image = image;
                    jeu.nom = nom;
                    jeu.prix = prix; 
                    jeu.categorie = categorie;                     
                    break;
                }
        }    
    var taille2=listePanier.length;
    if (taille2 === 0)
        {
            jeu.quantite++;
            listePanier.push(jeu);            
        }
    else 
    {
        var j = 0;
        for (j=0;j<taille2;j++)
        {
            var unJeu=listePanier[j];
            if(unJeu.nom == titre)
            {                
                 unJeu.quantite++;                
                 break;
            }            
        }
        if (j == taille2)
            {
                jeu.quantite++;
                listePanier.push(jeu);                
            }
    }
    totalPanier();
}

function supprimer(titre)
{
    var taille=listePanier.length;
    for (var i=0;i<taille;i++)
    {
        var unJeu=listePanier[i];
        if(unJeu.nom == titre)
            {                
                listePanier.splice(i, 1);
                break;
            }        
    }
    totalPanier();
    affichPanier();    
}

/*function retirer(titre)
{
    var taille=listePanier.length;
    for (var i=0;i<taille;i++)
    {
        var unJeu=listePanier[i];
        if(unJeu.nom == titre)
            {                
                listePanier[i].quantite--;
                break;
            }        
    }
    totalPanier();
    affichPanier();
}*/

function affichPanier()
{
    var image, nom, prix,categorie,quantite;
    var rep = "";	
	var taille=listePanier.length;    
	rep+="<h2>Liste des films dans le panier</h2><br><br><div class=\"row custom-center\"><div class=\"col-sm-12 col-md-10 col-md-offset-1 custom-center\"><table class=\"table table-hover\"><thead><tr><th>Produit</th><th class=\"text-center\">Catégorie</th><th class=\"text-center\">Quantité</th><th class=\"text-center\">Prix</th><th class=\"text-center\">Sous Total</th><th> </th><th> </th></tr></thead><tbody>";
	for (var i=0;i<taille;i++){
		var unJeu=listePanier[i];
		image=unJeu.image;
		nom=unJeu.nom;
        prix=unJeu.prix;
        categorie=unJeu.categorie;
        quantite=unJeu.quantite;		
        rep+="<tr><td class=\"col-sm-8 col-md-10\"><div class=\"media\"><a class=\"thumbnail pull-left\" href=\"#\"> <img class=\"boite\" src=\'"+image+"\' alt=\"Jeu "+categorie+"\" title=\"image de la boite du jeu "+nom+"\"></a><div class=\"media-body\"><h4 class=\"media-heading\"><a href=\"#\">"+nom+"</a></h4></div></div></td><td class=\"col-sm-1 col-md-1 text-center\"><strong>"+categorie+"</strong></td>                      <td class=\"col-sm-1 col-md-1 text-center\"><strong>"+quantite+"</strong></td><td class=\"col-sm-1 col-md-1 text-center\"><strong>"+prix+"$</strong></td><td class=\"col-sm-1 col-md-1 text-center\"><strong>"+eval(prix * quantite).toFixed(2)+"$</strong></td>";
        if (unJeu.quantite == 1)
            {
                rep+="<td class=\"col-sm-1 col-md-1\"></td><td class=\"col-sm-1 col-md-1\"><button type=\"button\" class=\"btn btn-danger\" onclick=\"supprimer(\'"+nom+"\')\">Supprimer</button></td>";                
            }
        else
            {
                rep+="<td class=\"col-sm-1 col-md-1\"><button type=\"button\" class=\"btn btn-warning\" onclick=\"retirer(\'"+nom+"\')\">&nbsp;Retirer&nbsp;</button></td><td class=\"col-sm-1 col-md-1\"><button type=\"button\" class=\"btn btn-danger\" onclick=\"supprimer(\'"+nom+"\')\">Supprimer</button></td>";                
            }
        rep+="</tr>";
	}
    rep+="<tr><td>   </td><td>   </td><td>   </td><td>   </td><td>   </td><td><h3>Total&nbsp;:</h3></td><td class=\"text-right\"><h3><strong>"+prixPanierTotal.toFixed(2)+"&nbsp;$</strong></h3></td></tr></tbody></table></div></div>";
    //var rep = "<h1>test</h1>";
	$('#contenu').html(rep);	
}

function totalPanier()
{
    nbrItemPanier = 0;
    prixPanierTotal = 0;
    var taille=listePanier.length;    
    for (var i=0;i<taille;i++)
    {
        nbrItemPanier+= listePanier[i].quantite;
        prixPanierTotal += listePanier[i].quantite * listePanier[i].prix;
    }
    var rep = "("+nbrItemPanier+") "+prixPanierTotal.toFixed(2)+" $"
    $('#totalPanier').html(rep);
}

/*function chercher()
{    
    var categorie, nom, prix,image;
    var titre = $('#recherche').val();    
	var tabJeux=listeJeux.getElementsByTagName("JEU");
	var taille=tabJeux.length;
	var rep="";    
	for (var i=0;i<taille;i++)
    {           
		categorie=tabJeux[i].getElementsByTagName("CATEGORIE")[0].firstChild.nodeValue;
		nom=tabJeux[i].getElementsByTagName("NOM")[0].firstChild.nodeValue;
        prix=tabJeux[i].getElementsByTagName("PRIX")[0].firstChild.nodeValue;
        image=tabJeux[i].getElementsByTagName("IMGSRC")[0].firstChild.nodeValue;
        if (nom == titre)
            {                
                rep+="<h2>Résultat de votre recherche</h2>";
                rep+="<tr><div class=\"container\"><div class=\"row\"><div class=\"col-sm-12 col-md-10 col-md-offset-1\"><table class=\"table table-hover\"><thead><tr><th>Produit</th><th class=\"text-center\">Catégorie</th> <th class=\"text-center\">Prix</th><th> </th></tr></thead><tbody><td class=\"col-sm-8 col-md-10\"><div class=\"media\"><a class=\"thumbnail pull-left\" href=\"#\"> <img class=\"boite\" src=\'"+image+"\' alt=\"Jeu "+categorie+"\" title=\"image de la boite du jeu"+nom+"\"></a><div class=\"media-body\"><h4 class=\"media-heading\"><a href=\"#\">"+nom+"</a></h4></div></div></td><td class=\"col-sm-1 col-md-1 text-center\"><strong>"+categorie+"</strong></td><td class=\"col-sm-1 col-md-1 text-center\"><strong>"+prix+"&nbsp;$</strong></td><td class=\"col-sm-1 col-md-1\"><button type=\"button\" class=\"btn btn-success\" onclick=\"ajouter(\'"+nom+"\')\">Ajouter</button></td></tr></tbody></table></div></div></div>";
                break;
            }        
	}
    if (i == taille)
        {
            rep+="<h2>Aucun jeu du nom de "+titre+" n'a été trouvé dans notre boutique</h2>"
        }
	$('#contenu').html(rep);
}

function envoie()
{
    alert("Message envoyé");
}

function test()
{
    var rep ="<div>test</div>";
    $('#contenu').html(rep);
}*/





