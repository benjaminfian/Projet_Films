<?php
include '../include/header.php';
require_once("../BD/connexion.inc.php");
$idFilm=$_POST['idFilm'];
$membre=$_POST['membre'];
$quantite=$_POST['quantite'];

$requete="SELECT * FROM connexion WHERE email = ?";
$stmt = $connexion->prepare($requete);
$stmt->execute(array($membre));
$ligne=$stmt->fetch(PDO::FETCH_OBJ);
$idMembre = $ligne->idMembre;

$requete="INSERT INTO location VALUES(0,?,?,?,now())";
$stmt = $connexion->prepare($requete);
$stmt->execute(array($idFilm,$idMembre,$quantite));
echo "Merci pour votre commande";

?>

<?php
include '../include/footer.php';
?>