<?php
session_start();
require_once("../BD/connexion.inc.php");
if(isset($_SESSION['user']))
{
    if($_POST['sauverPanier'] != null)
    {
        $panier=$_POST['sauverPanier'];
    }
    else
    {
        $panier = "";
    }
    $membre=$_SESSION['user'];

    $requete="SELECT * FROM connexion WHERE email = ?";
    $stmt = $connexion->prepare($requete);
    $stmt->execute(array($membre));
    $ligne=$stmt->fetch(PDO::FETCH_OBJ);
    $idMembre = $ligne->idMembre;

    $requete="UPDATE membre SET panier=? WHERE idMembre=?";
    $stmt=$connexion->prepare($requete);
    $stmt->execute(array($panier,$idMembre));
}

session_unset();
session_destroy();
include '../include/header.php';
echo "Vous etes deconnecté";
?>

<?php
include '../include/footer.php';
?>