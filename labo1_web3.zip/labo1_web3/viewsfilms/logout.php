<?php
session_start();
session_unset();
session_destroy();
include '../include/header.php';
echo "Vous etes deconnecté";
?>

<?php
include '../include/footer.php';
?>