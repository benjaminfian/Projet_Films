<?php
include '../include/header.php';
?>

<div id="contenu">
</div>

<?php
echo '<form id="form_commande" action="commander.php" method="POST">        
        <input type="hidden" name="membre" value="'.$_SESSION['user'].'">
        <input type="hidden" id="panier" name="panier">
      </form>';
?>
    
<?php
include '../include/footer.php';
?>