<?php
include '../include/header.php';
?>

<button onclick="affichPanier()">panier</button>


<div id="contenu">
</div>

    
<?php
include '../include/footer.php';
?>